package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.DisplayContext;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

import java.time.DateTimeException;

public class MainActivity extends AppCompatActivity {
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=(Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenCalculator();
            }
        });
    }
    public void OpenCalculator(){
        Intent intent= new Intent(this, Calculator.class);
        startActivity(intent);
    }
    TimePicker StartTime;
    TimePicker EndTime;

    int BerekenTijd(){
        int difHour = EndTime.getCurrentHour() - StartTime.getCurrentHour();
        int difMin = EndTime.getCurrentMinute() - StartTime.getCurrentMinute();
        TextView displayTextView = null;
        displayTextView.setText("Hello");
        return difHour * 60 + difMin;
    }
}